import React from 'react'
import '../css/workSlider.css';
import brand1 from '../assets/work1.png';
import brand2 from '../assets/work2.png';
import brand3 from '../assets/work3.png';
import brand4 from '../assets/work4.png';
import brand5 from '../assets/work1.png';
import brand6 from '../assets/work2.png';
import brand7 from '../assets/work3.png';
import brand8 from '../assets/work4.png';

const WorkSlider = () => {
  return (
   


<div class="worker">
	<div class="work-track">
		<div class="work">
			<img src={brand1} alt="Brands"  />
		</div>
		<div class="work">
			<img src={brand2} alt="Brands"  />
		</div>
		<div class="work">
			<img src={brand3} alt="Brands"  />
		</div>
		<div class="work">
			<img src={brand4} alt="Brands"  />
		</div>
        <div class="work">
			<img src={brand5} alt="Brands"  />
		</div>
        <div class="work">
			<img src={brand6} alt="Brands"  />
		</div>
        <div class="work">
			<img src={brand7} alt="Brands"  />
		</div>
        <div class="work">
			<img src={brand8} alt="Brands"  />
		</div>

        <div class="work">
			<img src={brand1} alt="Brands"  />
		</div>
		<div class="work">
			<img src={brand2} alt="Brands"  />
		</div>
		<div class="work">
			<img src={brand3} alt="Brands"  />
		</div>
		<div class="work">
			<img src={brand4} alt="Brands"  />
		</div>
        <div class="work">
			<img src={brand5} alt="Brands"  />
		</div>
        <div class="work">
			<img src={brand6} alt="Brands"  />
		</div>
        <div class="work">
			<img src={brand7} alt="Brands"  />
		</div>
        <div class="work">
			<img src={brand8} alt="Brands"  />
		</div>
		
	</div>
</div>

    
    


  )
}

export default WorkSlider